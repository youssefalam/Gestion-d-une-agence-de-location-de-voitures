package location.master.services;

public class CatClient {
	Integer code;
	String libelle;
	Float tauxremise;
	
	public Integer getcode() {
		return code;
	}

	public void setcode(Integer code) {
		this.code = code;
	}
	
	public String getlibelle() {
		return libelle;
	}

	public void setlibelle(String libelle) {
		this.libelle = libelle;
	}
	
	public Float gettauxremise() {
		return tauxremise;
	}

	public void settauxremise(Float tauxremise) {
		this.tauxremise = tauxremise;
	}


}
